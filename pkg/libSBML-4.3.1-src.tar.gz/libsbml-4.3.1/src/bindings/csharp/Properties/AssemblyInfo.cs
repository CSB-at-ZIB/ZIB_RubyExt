﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("libSBML C# Binding Proxy Class DLL")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("The SBML Team")]
[assembly: AssemblyProduct("libsbmlcsP.dll")]
[assembly: AssemblyCopyright("Copyright (C) The SBML Team 2010")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]

[assembly: ComVisible(false)]

[assembly: Guid("14def7f4-5e60-4925-b81e-f297ad1c3265")]

[assembly: AssemblyVersion("4.3.0.0")]
[assembly: AssemblyFileVersion("4.3.0.0")]
